package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.databinding.ActivityAdminNavigationBinding;
import com.google.android.material.navigation.NavigationView;

public class AdminNavigationActivity extends AppCompatActivity {
    private AppBarConfiguration aAppBarConfiguration;
    private ActivityAdminNavigationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String adminData = getIntent().getStringExtra("adminData");

        binding = ActivityAdminNavigationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarAdminNavigation.toolbar);

        DrawerLayout drawer = binding.drawerLayoutAdmin;
        NavigationView navigationView = binding.navView;
        // Exclude the logout button from top level destinations
        aAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_Admin_Profile, R.id.nav_Add_Admin, R.id.nav_view_all_orders, R.id.Add_Special_Offers)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_admin_navigation);
        NavigationUI.setupActionBarWithNavController(this, navController, aAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        navigationView.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.logoutButton) {
                // Handle logout action
                Intent intent = new Intent(AdminNavigationActivity.this, SignInAdminActivity.class);
                startActivity(intent);
                finish();  // Close the current activity
                return true;  // Indicate that the item selection was handled
            } else {
                // Handling other navigation items
                boolean handled = NavigationUI.onNavDestinationSelected(item, navController);
                if (handled) {
                    DrawerLayout draweer = binding.drawerLayoutAdmin;
                    draweer.closeDrawer(GravityCompat.START);  // Close drawer after item is selected
                }
                return handled;
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.admin_navigation, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_admin_navigation);
        return NavigationUI.navigateUp(navController, aAppBarConfiguration) || super.onSupportNavigateUp();
    }
}