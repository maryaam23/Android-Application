package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.databinding.ActivityCustomerNavigationBinding;
import android.Manifest;

public class CustomerNavigationActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityCustomerNavigationBinding binding;

    // File: FragmentCommunicators.java
    public interface CartUpdateListener {
        void onAddToCart(CartModel cartItem);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityCustomerNavigationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarCustomerNavigation.toolbar);

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Exclude the logout button from top level destinations
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_pizza_menu, R.id.nav_your_orders, R.id.yourFavoriteFragment, R.id.specialOffersFragment, R.id.profileFragment, R.id.callusorFindusFragment)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_customer_navigation);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        navigationView.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.logoutButton) {
                // Handle logout action
                Intent intent = new Intent(CustomerNavigationActivity.this, SignInActivity.class);
                startActivity(intent);
                finish();  // Close the current activity
                return true;  // Indicate that the item selection was handled
            } else {
                // Handling other navigation items
                boolean handled = NavigationUI.onNavDestinationSelected(item, navController);
                if (handled) {
                    DrawerLayout draweer = binding.drawerLayout;
                    draweer.closeDrawer(GravityCompat.START);  // Close drawer after item is selected
                }
                return handled;
            }
        });


        // Retrieve the passed details
        Intent intent = getIntent();
        String customerEmail = intent.getStringExtra("CustomerEmail");
        String customerName = intent.getStringExtra("CustomerName");



        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = headerView.findViewById(R.id.name);
        TextView navUserEmail = headerView.findViewById(R.id.email);

        navUsername.setText(customerName);
        navUserEmail.setText(customerEmail);
/*
        ImageView profileImageView = findViewById(R.id.imageView); // Make sure you have this ImageView in your layout
        profileImageView.setOnClickListener(v -> {
            // Check if the permission has already been granted
            // Inside your activity's onCreate or similar lifecycle method
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            } else {
                // Permission has already been granted
                pickImageFromGallery();
            }

        });*/

    }
/*

    // Method to launch gallery for image selection
    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 100); // Arbitrary request code
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) { // Make sure this matches the request code in the requestPermissions call
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // If permission was granted, proceed with the image selection
                pickImageFromGallery();
            } else {
                // Permission was denied, show an appropriate message
                Toast.makeText(this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            ImageView profileImageView = findViewById(R.id.imageView);
            profileImageView.setImageURI(imageUri);
            // Handle uploading the image to your server or database as needed
        }
    }
*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.customer_navigation, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_customer_navigation);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration) || super.onSupportNavigateUp();
    }
}
