package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends android.database.sqlite.SQLiteOpenHelper{
    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE CUSTOMER(EMAIL TEXT PRIMARY KEY,FIRSTNAME TEXT,LASTNAME TEXT, PHONE TEXT,GENDER TEXT, PASSWORD TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertCustomer(Customer customer) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("EMAIL", customer.getEmail());
            contentValues.put("FIRSTNAME", customer.getFirstName());
            contentValues.put("LASTNAME", customer.getLastName());
            contentValues.put("PHONE", customer.getPhone());
            contentValues.put("GENDER", customer.getGender());
            contentValues.put("PASSWORD", customer.getPassword());
            db.insert("CUSTOMER", null, contentValues);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            db.close();
        }
    }


    public boolean emailExists(String email) {
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT EMAIL FROM CUSTOMER WHERE EMAIL = ?";
        try (Cursor cursor = db.rawQuery(query, new String[]{email})) {
            return cursor.getCount() > 0;
        } finally {
            db.close();
        }
    }



    @SuppressLint("Range")
    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CUSTOMER", null);
        if (cursor.moveToFirst()) {
            do {
                Customer customer = new Customer();
                customer.setEmail(cursor.getString(cursor.getColumnIndex("EMAIL")));
                customer.setFirstName(cursor.getString(cursor.getColumnIndex("FIRSTNAME")));
                customer.setLastName(cursor.getString(cursor.getColumnIndex("LASTNAME")));
                customer.setPhone(cursor.getString(cursor.getColumnIndex("PHONE")));
                customer.setGender(cursor.getString(cursor.getColumnIndex("GENDER")));
                customer.setPassword(cursor.getString(cursor.getColumnIndex("PASSWORD")));  // Note: Storing passwords in plaintext is a security risk!
                customers.add(customer);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return customers;
    }

    public boolean validateUser(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = { "EMAIL", "PASSWORD" };
        String selection = "EMAIL = ? AND PASSWORD = ?";
        String[] selectionArgs = { email, hashPassword(password) }; // Assumes you have a hashPassword method that hashes the password before checking

        try (Cursor cursor = db.query("CUSTOMER", columns, selection, selectionArgs, null, null, null)) {
            return cursor.moveToFirst(); // Returns true if there is at least one record (i.e., the user exists and password matches)
        } finally {
            db.close();
        }
    }
    public String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(encodedhash, Base64.DEFAULT);
        } catch (NoSuchAlgorithmException e) {
            Log.e("HASH", "Hashing algorithm not supported", e);
            return null;
        }
    }

    @SuppressLint("Range")
    public Customer getUserDetails(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = {"EMAIL", "FIRSTNAME", "LASTNAME", "PASSWORD"};
        String selection = "EMAIL = ? AND PASSWORD = ?";
        String[] selectionArgs = {email, hashPassword(password)};

        Cursor cursor = db.query("CUSTOMER", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Customer customer = new Customer();
            customer.setEmail(cursor.getString(cursor.getColumnIndex("EMAIL")));
            customer.setFirstName(cursor.getString(cursor.getColumnIndex("FIRSTNAME")));
            customer.setLastName(cursor.getString(cursor.getColumnIndex("LASTNAME")));
            cursor.close();
            db.close();
            return customer;
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return null;
    }

    @SuppressLint("Range")
    public Customer getCustomerDetails(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String hashedPassword = hashPassword(password);
        if (hashedPassword == null) {
            Log.e("DataBaseHelper", "Failed to hash password");
            return null;
        }

        String[] columns = {"EMAIL", "FIRSTNAME", "LASTNAME", "PHONE", "GENDER"};
        String selection = "EMAIL = ? AND PASSWORD = ?";
        String[] selectionArgs = {email, hashedPassword};
        Customer customer = null;

        Cursor cursor = null;
        try {
            cursor = db.query("CUSTOMER", columns, selection, selectionArgs, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                customer = new Customer();
                customer.setEmail(cursor.getString(cursor.getColumnIndex("EMAIL")));
                customer.setFirstName(cursor.getString(cursor.getColumnIndex("FirstName")));
                customer.setLastName(cursor.getString(cursor.getColumnIndex("LastName")));
                customer.setPhone(cursor.getString(cursor.getColumnIndex("Phone")));
                customer.setGender(cursor.getString(cursor.getColumnIndex("Gender")));
                // Do not return or store the password in the Customer object
            } else {
                Log.d("DataBaseHelper", "No customer found with the provided email and password");
            }
        } catch (Exception e) {
            Log.e("DataBaseHelper", "Error fetching customer details", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return customer;
    }
    @SuppressLint("Range")
    public Customer getCustomerByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Customer customer = null;

        String[] columns = { "EMAIL", "FIRSTNAME", "LASTNAME", "PHONE", "GENDER", "PASSWORD" }; // Consider omitting PASSWORD if it's not necessary to display
        String selection = "EMAIL = ?";
        String[] selectionArgs = { email };

        Cursor cursor = db.query("CUSTOMER", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            customer = new Customer();
            customer.setEmail(cursor.getString(cursor.getColumnIndex("EMAIL")));
            customer.setFirstName(cursor.getString(cursor.getColumnIndex("FIRSTNAME")));
            customer.setLastName(cursor.getString(cursor.getColumnIndex("LASTNAME")));
            customer.setPhone(cursor.getString(cursor.getColumnIndex("PHONE")));
            customer.setGender(cursor.getString(cursor.getColumnIndex("GENDER")));
            // Do not retrieve or set the password in your application logic if it is not necessary
        }

        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return customer;
    }
    public void updateProfileInDatabase(String firstName, String lastName, String email, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Hash the password before storing it
        String hashedPassword = hashPassword(password);

        ContentValues values = new ContentValues();
        values.put("FIRSTNAME", firstName);
        values.put("LASTNAME", lastName);
        values.put("PHONE", phone);
        values.put("PASSWORD", hashedPassword);

        // Assuming 'EMAIL' is the primary key and doesn't change
        String selection = "EMAIL = ?";
        String[] selectionArgs = { email };

        try {
            int count = db.update("CUSTOMER", values, selection, selectionArgs);
            Log.d("DatabaseHelper", "Updated rows: " + count);
        } finally {
            db.close();
        }
    }


    @SuppressLint("Range")
    public String getStoredPassword(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT PASSWORD FROM CUSTOMER WHERE EMAIL = ?";
        try (Cursor cursor = db.rawQuery(query, new String[]{email})) {
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndex("PASSWORD"));
            }
        } finally {
            db.close();
        }
        return null;
    }




}
