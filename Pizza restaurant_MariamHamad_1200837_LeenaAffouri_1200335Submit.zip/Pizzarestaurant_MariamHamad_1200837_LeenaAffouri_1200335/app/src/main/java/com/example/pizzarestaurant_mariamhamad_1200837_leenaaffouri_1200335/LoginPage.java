package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LoginPage extends AppCompatActivity {

    private Button signInButton, signInButton2;
    private Button signUpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        // Initialize buttons
        signInButton = findViewById(R.id.signInButton);
        signInButton2 = findViewById(R.id.signInButton2);
        signUpButton = findViewById(R.id.signUpButton);

        // Set click listener for Sign In button
        signInButton.setOnClickListener(v -> {
            // Intent to go to SignInActivity
            Intent signInIntent = new Intent(LoginPage.this, SignInActivity.class);
            startActivity(signInIntent);
        });

        // Set click listener for Sign In button
        signInButton2.setOnClickListener(v -> {
            // Intent to go to SignInActivity
            Intent SignInAdminIntent = new Intent(LoginPage.this, SignInAdminActivity.class);
            startActivity(SignInAdminIntent);
        });

        // Set click listener for Sign Up button
        signUpButton.setOnClickListener(v -> {
            // Intent to go to SignUpActivity
            Intent signUpIntent = new Intent(LoginPage.this, SignUpActivity.class);
            startActivity(signUpIntent);
        });
    }
}
