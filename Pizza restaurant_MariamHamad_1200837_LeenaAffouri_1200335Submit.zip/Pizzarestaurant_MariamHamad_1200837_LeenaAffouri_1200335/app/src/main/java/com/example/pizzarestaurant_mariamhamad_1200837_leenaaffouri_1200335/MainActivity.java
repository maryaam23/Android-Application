package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.CartAdapter;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.slideshow.Yourorders;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button getStartedButton;


    private final String URL = "https://18fbea62d74a40eab49f72e12163fe6c.api.mockbin.io/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getStartedButton = findViewById(R.id.getStartedButton);
        getStartedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadPizzaTypes();
            }
        });
    }

    private void loadPizzaTypes() {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("API Response", response);  // Log the response
                        try {
                            JSONObject jsonObject = new JSONObject(response);  // First parse the string into a JSONObject
                            JSONArray jsonArray = jsonObject.getJSONArray("types");  // Then get the array using the correct key
                            goToLoginRegistrationSection();
                            // Optionally, you could do something with jsonArray here, such as storing it or passing it to the next activity.
                        } catch (JSONException e) {
                            Log.e("JSON Parsing Error", e.getMessage(), e);
                            showError("Parsing error: " + e.getMessage());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley Error", error.toString(), error);
                Toast.makeText(MainActivity.this, "Failed to connect. Please try again.", Toast.LENGTH_LONG).show();
            }
        });
        queue.add(stringRequest);
    }




    private void goToLoginRegistrationSection() {
        // Intent to start a new Activity, e.g., LoginActivity
        Intent intent = new Intent(MainActivity.this, LoginPage.class);
       startActivity(intent);
    }

    private void showError(String errorMessage) {
        // Show error message using Toast or a TextView
        Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
    }





}