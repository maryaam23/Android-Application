package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import androidx.recyclerview.widget.RecyclerView;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.Model;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.VerticalModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    UpdateVerticalRec updateVerticalRec;
    Activity activity;
    ArrayList<Model> list;

    boolean check = true;
    boolean select = true;
    int row_index = -1;

    public Adapter(UpdateVerticalRec updateVerticalRec, Activity activity, ArrayList<Model> list) {
        this.updateVerticalRec = updateVerticalRec;
        this.activity = activity;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_horizental, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.imageView.setImageResource(list.get(position).getImage());
        holder.name.setText(list.get(position).getName());

        if (check) {
            ArrayList<VerticalModel> VerModelList = new ArrayList<>();
            VerModelList.add(new VerticalModel(R.drawable.margarita, "Pizza Margarita", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.neapolitan, "Pizza Neapolitan", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.hawa, "Pizza Hawaiian", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.pepperoni, "Pizza Pepperoni", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.newyork, "Pizza New York Style", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.calzone, "Pizza Calzone", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.tandoori, "Pizza Tandoori Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.bbq, "Pizza BBQ Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.seafood, "Pizza Seafood", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.vegetable, "Pizza Vegetarian", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.buffalo, "Pizza Buffalo Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.mushroom, "Pizza Mushroom Truffle", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
            VerModelList.add(new VerticalModel(R.drawable.pesto, "Pizza Pesto Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));

            updateVerticalRec.callBack(position, VerModelList);
        }


        check = false;
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                row_index = position;
                notifyDataSetChanged();

                if (position == 0) {
                    ArrayList<VerticalModel> VerModelList = new ArrayList<>();
                    VerModelList.add(new VerticalModel(R.drawable.margarita, "Pizza Margarita", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.neapolitan, "Pizza Neapolitan", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.hawa, "Pizza Hawaiian", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.pepperoni, "Pizza Pepperoni", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.newyork, "Pizza New York Style", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.calzone, "Pizza Calzone", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.tandoori, "Pizza Tandoori Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.bbq, "Pizza BBQ Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.seafood, "Pizza Seafood", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.vegetable, "Pizza Vegetarian", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.buffalo, "Pizza Buffalo Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.mushroom, "Pizza Mushroom Truffle", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));
                    VerModelList.add(new VerticalModel(R.drawable.pesto, "Pizza Pesto Chicken", "10 - 20 min", "4.9", "S 30$, M 40$, L 50$", "Pizza"));

                    updateVerticalRec.callBack(position, VerModelList);
                } else if (position == 1) {
                    ArrayList<VerticalModel> VerModelList = new ArrayList<>();
                    VerModelList.add(new VerticalModel(R.drawable.garlic, "Garlic Bread", "10 min", "4.9", "S 10$, M 15$, L 20$", "Appetizers"));
                    VerModelList.add(new VerticalModel(R.drawable.mozzarella, "Mozzarella Sticks", "10 min", "4.9", "S 10$, M 15$, L 20$", "Appetizers"));
                    VerModelList.add(new VerticalModel(R.drawable.wings, "Wings", "10 min", "4.9", "S 10$, M 15$, L 20$", "Appetizers"));
                    updateVerticalRec.callBack(position, VerModelList);
                } else if (position == 2) {
                    ArrayList<VerticalModel> VerModelList = new ArrayList<>();
                    VerModelList.add(new VerticalModel(R.drawable.caesar, "Caesar Salad", "10 min", "4.9", "S 15$, M 20$, L 25$", "Salads"));
                    VerModelList.add(new VerticalModel(R.drawable.garden, "Garden Salad", "10 min", "4.9", "S 15$, M 20$, L 25$","Salads"));
                    updateVerticalRec.callBack(position, VerModelList);
                } else if (position == 3) {
                    ArrayList<VerticalModel> VerModelList = new ArrayList<>();
                    VerModelList.add(new VerticalModel(R.drawable.tiramisu, "Tiramisu", "5 min", "4.9", "S 20$, M 25$, L 30$","Desserts"));
                    VerModelList.add(new VerticalModel(R.drawable.panna, "Panna Cotta", "5 min", "4.9", "S 20$, M 25$, L 30$","Desserts"));
                    VerModelList.add(new VerticalModel(R.drawable.chocolate, "Chocolate Lava Cake", "5 min", "4.9", "S 20$, M 25$, L 30$","Desserts"));
                    VerModelList.add(new VerticalModel(R.drawable.cheesecake, "Cheesecake", "5 min", "4.9", "S 20$, M 25$, L 30$","Desserts"));
                    updateVerticalRec.callBack(position, VerModelList);
                } else if (position == 4) {
                    ArrayList<VerticalModel> VerModelList = new ArrayList<>();
                    VerModelList.add(new VerticalModel(R.drawable.iced, "Iced Tea", "5 min", "4.9", "S 20$, M 25$, L 30$", "Drinks"));
                    VerModelList.add(new VerticalModel(R.drawable.lemonade, "Lemonade", "5 min", "4.9", "S 20$, M 25$, L 30$", "Drinks"));
                    VerModelList.add(new VerticalModel(R.drawable.water, "Water", "5 min", "4.9", "15$", "Drinks"));
                    VerModelList.add(new VerticalModel(R.drawable.milkshakes, "Milkshakes", "5 min", "4.9", "S 20$, M 25$, L 30$", "Drinks"));
                    VerModelList.add(new VerticalModel(R.drawable.coffee, "Coffee", "5 min", "4.9", "S 20$, M 25$, L 30$", "Drinks"));
                    updateVerticalRec.callBack(position, VerModelList);
                }
            }
        });

        if (select) {
            if (position == 0) {
                holder.cardView.setBackgroundResource(R.drawable.change_bg);
                select = false;
            }
        } else {
            if (row_index == position) {
                holder.cardView.setBackgroundResource(R.drawable.change_bg);
            } else {
                holder.cardView.setBackgroundResource(R.drawable.defult);
            }
        }





    }

    @Override
    public int getItemCount() {

        return list.size();
    }





    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView name;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.hor_img);
            name = itemView.findViewById(R.id.hor_text);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}
