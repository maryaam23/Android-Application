package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter;

import android.content.ClipData;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.slideshow.CartItemRemoveListener;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.slideshow.Yourorders;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {


    private CartItemRemoveListener listener;
    private Context context;
    private List<CartModel> list;

    public CartAdapter(Context context, List<CartModel> list) {
        this.context = context;
        this.list = list;
    }

    public CartAdapter (List<CartModel> list) {

        this.list=list;
    }

    public CartAdapter(Context context, List<CartModel> list, CartItemRemoveListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.mycard_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.imageView.setImageResource(list.get(position).getImage());
        holder.name.setText(list.get(position).getName());
        holder.rating.setText(list.get(position).getRating()); // Assuming rating is a String. If not, convert it to String
        holder.price.setText(list.get(position).getPrice()); // Assuming price is a String. If not, convert it to String
        holder.Quantity.setText(String.valueOf(list.get(position).getQuantity()));

        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemRemoved(position);
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView name, rating, price,Quantity;
        ImageButton deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.detailed_img);
            name = itemView.findViewById(R.id.detailed_name);
            rating = itemView.findViewById(R.id.detailed_rating);
            price = itemView.findViewById(R.id.price_amount); // Updated the ID based on your image
            Quantity = itemView.findViewById(R.id.quantity_amount);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
