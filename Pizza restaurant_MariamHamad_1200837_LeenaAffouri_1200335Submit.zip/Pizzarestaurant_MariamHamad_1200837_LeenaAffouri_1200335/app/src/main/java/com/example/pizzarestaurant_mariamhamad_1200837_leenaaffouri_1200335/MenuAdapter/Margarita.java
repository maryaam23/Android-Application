package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MainActivity;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.Pizza;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.SharedViewModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav.FavoriteModel;

import java.util.ArrayList;
import java.util.List;
import android.widget.ImageButton;

public class Margarita extends Fragment {
    private SharedViewModel viewModel;
    private static final String ARG_PIZZA = "pizza";
    private Pizza pizza;
    private double selectedPrice;
    private String selectedSize = "M"; // Default size
    private int quantity = 1;
    private double totalPrice;
    public static Margarita newInstance(Pizza pizza) {
        Margarita fragment = new Margarita();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PIZZA, pizza); // Remove unnecessary casting to Serializable
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_margarita, container, false);
        if (getArguments() != null && getArguments().containsKey(ARG_PIZZA)) {
            pizza = (Pizza) getArguments().getSerializable(ARG_PIZZA);
            setupPizzaDetails(view, pizza);
        }
        viewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        Button addToCartButton = view.findViewById(R.id.add_to_cart);
        addToCartButton.setOnClickListener(v -> {
            if (pizza != null) {
                String description = pizza.getName() + " - " + selectedSize ;;
                CartModel newItem = new CartModel(pizza.getImageResource(), description, String.format("%.2f NIS", totalPrice), "4.5",quantity );
                viewModel.addCartItem(newItem);
                Toast.makeText(getContext(), "Added " + description + " to Cart", Toast.LENGTH_SHORT).show();
            }
        });

        ImageButton heartButton = view.findViewById(R.id.heart);
        heartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pizza != null) {
                    String description = pizza.getName() + " - " + selectedSize ;;
                    FavoriteModel newItem = new FavoriteModel(pizza.getImageResource(), description, String.format("%.2f NIS", totalPrice), "4.5");
                    viewModel.addToFavorites(newItem);
                    Toast.makeText(getContext(), "Added " + description + " to Favorites", Toast.LENGTH_SHORT).show();
                }
            }
        });




        if (getArguments() != null && getArguments().containsKey(ARG_PIZZA)) {
            pizza = (Pizza) getArguments().getSerializable(ARG_PIZZA);

            ImageView pizzaImage = view.findViewById(R.id.pizza_image);
            TextView pizzaName = view.findViewById(R.id.pizza_name);
            TextView pizzaDescription = view.findViewById(R.id.pizza_description);
            TextView smallPriceTextView = view.findViewById(R.id.small_price);
            TextView mediumPriceTextView = view.findViewById(R.id.medium_price);
            TextView largePriceTextView = view.findViewById(R.id.large_price);

            smallPriceTextView.setText(String.format("S $%.2f", pizza.getPriceSmall()));
            mediumPriceTextView.setText(String.format("M $%.2f", pizza.getPriceMedium()));
            largePriceTextView.setText(String.format("L $%.2f", pizza.getPriceLarge()));

            pizzaImage.setImageResource(pizza.getImageResource());
            pizzaName.setText(pizza.getName());
            pizzaDescription.setText(pizza.getDescription());
        }



        Button backButton = view.findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simply remove this fragment from the view
                FragmentManager fragmentManager = getFragmentManager();
                if (fragmentManager != null) {
                    FragmentTransaction transaction = fragmentManager.beginTransaction();
                    transaction.remove(Margarita.this); // Remove this fragment
                    transaction.commit();
                }
            }
        });

        // Assuming there is an item view setup context, otherwise this needs context clarification



        return view; // This return should be outside the OnClickListener
    }


    private void setupPizzaDetails(View view, Pizza pizza) {
        ImageView pizzaImage = view.findViewById(R.id.pizza_image);
        TextView pizzaName = view.findViewById(R.id.pizza_name);
        TextView pizzaDescription = view.findViewById(R.id.pizza_description);
        TextView smallPriceTextView = view.findViewById(R.id.small_price);
        TextView mediumPriceTextView = view.findViewById(R.id.medium_price);
        TextView largePriceTextView = view.findViewById(R.id.large_price);
        Button smallButton = view.findViewById(R.id.small);
        Button mediumButton = view.findViewById(R.id.medium);
        Button largeButton = view.findViewById(R.id.large);
        ImageButton plusButton = view.findViewById(R.id.plus);
        ImageButton minusButton = view.findViewById(R.id.minus);
        TextView quantityTextView = view.findViewById(R.id.quantityTextView);  // Ensure you have this TextView in your layout

        smallPriceTextView.setText(String.format("S $%.2f", pizza.getPriceSmall()));
        mediumPriceTextView.setText(String.format("M $%.2f", pizza.getPriceMedium()));
        largePriceTextView.setText(String.format("L $%.2f", pizza.getPriceLarge()));

        pizzaImage.setImageResource(pizza.getImageResource());
        pizzaName.setText(pizza.getName());
        pizzaDescription.setText(pizza.getDescription());
        quantityTextView.setText(String.valueOf(quantity));
        // Default selected price is medium
        selectedPrice = pizza.getPriceMedium();
        updateTotalPrice();

        smallButton.setOnClickListener(v -> {
            selectedSize = "S";
            selectedPrice = pizza.getPriceSmall();
            Toast.makeText(getContext(), "Small size selected", Toast.LENGTH_SHORT).show();
            updateTotalPrice();
        });

        mediumButton.setOnClickListener(v -> {
            selectedSize = "M";
            selectedPrice = pizza.getPriceMedium();
            Toast.makeText(getContext(), "Medium size selected", Toast.LENGTH_SHORT).show();
            updateTotalPrice();
        });

        largeButton.setOnClickListener(v -> {
            selectedSize = "L";
            selectedPrice = pizza.getPriceLarge();
            Toast.makeText(getContext(), "Large size selected", Toast.LENGTH_SHORT).show();
            updateTotalPrice();
        });

        plusButton.setOnClickListener(v -> {
            quantity++;
            quantityTextView.setText(String.valueOf(quantity));
            updateTotalPrice();
        });

        minusButton.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                quantityTextView.setText(String.valueOf(quantity));
                updateTotalPrice();
            }
        });
    }
    private void updateTotalPrice() {
        totalPrice = selectedPrice * quantity;
        Toast.makeText(getContext(), "Total: " + String.format("%.2f NIS", totalPrice), Toast.LENGTH_SHORT).show();
    }
}