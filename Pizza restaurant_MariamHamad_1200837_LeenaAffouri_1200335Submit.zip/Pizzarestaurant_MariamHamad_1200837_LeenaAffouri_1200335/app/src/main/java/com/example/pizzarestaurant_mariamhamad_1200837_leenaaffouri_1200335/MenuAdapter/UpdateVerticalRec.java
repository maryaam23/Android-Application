package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.VerticalModel;

import java.util.ArrayList;

public interface UpdateVerticalRec {

    public void callBack(int position, ArrayList<VerticalModel> list);
}
