package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.Model;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.Pizza;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.VerticalModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class VerticalAdapter extends RecyclerView.Adapter<VerticalAdapter.ViewHolder> {
    Context context;
    ArrayList<VerticalModel> itemList;

    private ArrayList<VerticalModel> originalList;
    private OnItemClickListener listener;
    private HashMap<Integer, Boolean> isFragmentVisibleMap = new HashMap<>();
    List<CartModel> list;
    CartAdapter cartAdapter;
    RecyclerView recyclerView;




    public VerticalAdapter(Context context, ArrayList<VerticalModel> itemList) {
        this.context = context;
        this.itemList = itemList;
        this.isFragmentVisibleMap = new HashMap<>();
    }

    public VerticalAdapter(Context context, OnItemClickListener listener) {
        this.context = context;
        this.listener = listener;
        this.isFragmentVisibleMap = new HashMap<>();
    }


    public interface OnItemClickListener {
        void onItemClick(int position);
    }
    // File: FragmentCommunicators.java
    public interface CartUpdateListener {
        void onAddToCart(CartModel cartItem);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_vertical, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        VerticalModel model = itemList.get(position);
        holder.imageButton.setImageResource(model.getImage());
        holder.name.setText(model.getName());
        holder.timing.setText(model.getTiming());
        holder.rating.setText(model.getRating());
        holder.price.setText(model.getPrice());

        holder.imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                Fragment selectedFragment = getFragmentByCategory(model.getCategory(), position);
                activity.getSupportFragmentManager().beginTransaction()
                        .replace(R.id.f, selectedFragment)
                        .addToBackStack(null)
                        .commit();
            }
        });





    }


    private Fragment getFragmentByCategory(String category, @SuppressLint("RecyclerView") int position) {
        Pizza pizza;

        switch (category) {
            case "Pizza":
                switch (position) {
                    case 0:
                        pizza = new Pizza(R.drawable.margarita, "Margarita Pizza", "A bubbly crust, crushed San Marzano tomato sauce, fresh mozzarella and basil, a drizzle of olive oil, and a sprinkle of salt", 30.00, 40.00, 50.00);

                        break;
                    case 1:
                        pizza = new Pizza(R.drawable.neapolitan, "Neapolitan Pizza", "Authentic Neapolitan with fresh mozzarella.", 30.00, 40.00, 50.00);
                        break;
                    case 2:
                        pizza = new Pizza(R.drawable.hawia, "Hawaiian Pizza", "Ham and pineapple for a sweet and savory taste.", 30.00, 40.00, 50.00);
                        break;
                    case 3:
                        pizza = new Pizza(R.drawable.pepperoni, "Pepperoni Pizza", "Delicious pepperoni with extra cheese.", 30.00, 40.00, 50.00);
                        break;
                    case 4:
                        pizza = new Pizza(R.drawable.newyork, "New York Style Pizza", "Thin crust with a liberal amount of marinara sauce.", 30.00, 40.00, 50.00);
                        break;
                    case 5:
                        pizza = new Pizza(R.drawable.calzone, "Calzone Pizza", "Folded pizza stuffed with ricotta and ham.", 30.00, 40.00, 50.00);
                        break;
                    case 6:
                        pizza = new Pizza(R.drawable.tandoori, "Tandoori Chicken Pizza", "Spicy tandoori chicken with red onions.", 30.00, 40.00, 50.00);
                        break;
                    case 7:
                        pizza = new Pizza(R.drawable.bbq, "BBQ Chicken Pizza", "BBQ sauce with chicken and cilantro.", 30.00, 40.00, 50.00);
                        break;
                    case 8:
                        pizza = new Pizza(R.drawable.seafood, "Seafood Pizza", "Topped with assorted seafood.", 30.00, 40.00, 50.00);
                        break;
                    case 9:
                        pizza = new Pizza(R.drawable.vegetable, "Vegetarian Pizza", "Loaded with fresh vegetables.", 30.00, 40.00, 50.00);
                        break;
                    case 10:
                        pizza = new Pizza(R.drawable.buffalo, "Buffalo Chicken Pizza", "Buffalo chicken and blue cheese topping.", 30.00, 40.00, 50.00);
                        break;
                    case 11:
                        pizza = new Pizza(R.drawable.mushroom, "Mushroom Truffle Pizza", "Mushrooms with truffle oil.", 30.00, 40.00, 50.00);
                        break;
                    case 12:
                        pizza = new Pizza(R.drawable.pesto, "Pesto Chicken Pizza", "Chicken with pesto base.", 30.00, 40.00, 50.00);
                        break;
                    default:
                        pizza = new Pizza(R.drawable.heart, "Cheese Pizza", "Simple yet delicious cheese pizza.", 30.00, 40.00, 50.00);
                        break;
                }
                return Margarita.newInstance(pizza);

            // Add more categories with specific fragments based on position
            case "Appetizers":

                switch (position) {
                    case 0:
                        pizza = new Pizza(R.drawable.garlic, "Garlic Bread", "Freshly baked bread with a rich garlic butter spread, served warm.", 10.00, 15.00, 20.00);
                        break;
                    case 1:
                        pizza = new Pizza(R.drawable.mozzarella, "Mozzarella Sticks", "Crispy golden sticks filled with creamy mozzarella, served with marinara sauce.", 10.00, 15.00, 20.00);
                        break;
                    case 2:
                        pizza = new Pizza(R.drawable.wings, "Wings", "Spicy and savory chicken wings served with a side of blue cheese dressing.", 10.00, 15.00, 20.00);
                        break;
                    default:
                        pizza = new Pizza(R.drawable.heart, "Assorted Appetizers", "A selection of our finest starters.", 10.00, 15.00, 20.00);
                        break;
                }
                return Margarita.newInstance(pizza);

            case "Salads":

                switch (position) {
                    case 0:
                        pizza = new Pizza(R.drawable.caesar, "Caesar Salad", "Classic Caesar with romaine lettuce, parmesan cheese, croutons, and creamy Caesar dressing.", 15.00, 20.00, 25.00);
                        break;
                    case 1:
                        pizza = new Pizza(R.drawable.garden, "Garden Salad", "A fresh mix of seasonal greens, tomatoes, cucumbers, and carrots with your choice of dressing.", 15.00, 20.00, 25.00);
                        break;
                    default:
                        pizza = new Pizza(R.drawable.heart, "House Salad", "Our house salad with a blend of fresh greens and garden vegetables.", 15.00, 20.00, 25.00);
                        break;
                }
                return Margarita.newInstance(pizza);

            case "Desserts":

                switch (position) {
                    case 0:
                        pizza = new Pizza(R.drawable.tiramisu, "Tiramisu", "Layered Italian dessert made with mascarpone, espresso-soaked ladyfingers, and dusted with cocoa powder.", 20.00, 25.00, 30);
                        break;
                    case 1:
                        pizza = new Pizza(R.drawable.panna, "Panna Cotta", "Silky smooth Italian custard dessert topped with berry compote.", 20.00, 25.00, 30);
                        break;
                    case 2:
                        pizza = new Pizza(R.drawable.chocolate, "Chocolate Lava Cake", "Warm chocolate cake with a flowing molten chocolate center, served with vanilla ice cream.", 20.00, 25.00, 30);
                        break;
                    case 3:
                        pizza = new Pizza(R.drawable.cheesecake, "Cheesecake", "Rich and creamy cheesecake on a graham cracker crust with a fruit topping.", 20.00, 25.00, 30);
                        break;
                    default:
                        pizza = new Pizza(R.drawable.heart, "Seasonal Dessert", "A special dessert made from seasonally available ingredients.", 20.00, 25.00, 30);
                        break;
                }
                return Margarita.newInstance(pizza);

            case "Drinks":

                switch (position) {
                    case 0:
                        pizza = new Pizza(R.drawable.iced, "Iced Tea", "Refreshing cold brewed iced tea with a hint of lemon.", 20.00, 25.00, 30);
                        break;
                    case 1:
                        pizza = new Pizza(R.drawable.lemonade, "Lemonade", "Homemade lemonade made from freshly squeezed lemons, served chilled.", 20.00, 25.00, 30);
                        break;
                    case 2:
                        pizza = new Pizza(R.drawable.water, "Mineral Water", "Natural mineral water to keep you hydrated.", 20.00, 25.00, 30);
                        break;
                    case 3:
                        pizza = new Pizza(R.drawable.milkshakes, "Milkshakes", "Thick and creamy milkshakes available in vanilla, chocolate, or strawberry.", 20.00, 25.00, 30);
                        break;
                    case 4:
                        pizza = new Pizza(R.drawable.coffee, "Coffee", "Freshly brewed coffee, served hot with options for sugar and cream.", 20.00, 25.00, 30);
                        break;
                    default:
                        pizza = new Pizza(R.drawable.heart, "Assorted Beverages", "Choose from our wide range of beverages.", 20.00, 25.00, 30);
                        break;
                }
                return Margarita.newInstance(pizza);

            default:
                pizza = new Pizza(R.drawable.heart, "Default Pizza", "An assorted pizza", 20.00, 25.00, 30);
                return Margarita.newInstance(pizza);
        }
    }


    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageButton imageButton;
        TextView name, timing, rating, price;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageButton = itemView.findViewById(R.id.ver_img);
            name = itemView.findViewById(R.id.name);
            timing = itemView.findViewById(R.id.timing);
            rating = itemView.findViewById(R.id.rating);
            price = itemView.findViewById(R.id.price);
        }

    }

}