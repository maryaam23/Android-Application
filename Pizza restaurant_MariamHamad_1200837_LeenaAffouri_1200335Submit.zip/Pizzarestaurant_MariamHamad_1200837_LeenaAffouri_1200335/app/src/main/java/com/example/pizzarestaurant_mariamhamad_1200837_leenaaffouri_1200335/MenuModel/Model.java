package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel;

public class Model {

    int image;
    String name;

    public Model(int image, String name) {

        this.image = image;
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Model{" +
                "image=" + image +
                ", name='" + name + '\'' +
                '}';
    }

}
