package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel;

import java.io.Serializable;

public class Pizza implements Serializable {
    private int imageResource;
    private String name;
    private String description;
    private double priceSmall;
    private double priceMedium;
    private double priceLarge;

    // Constructor with added price parameters
    public Pizza(int imageResource, String name, String description, double priceSmall, double priceMedium, double priceLarge) {
        this.imageResource = imageResource;
        this.name = name;
        this.description = description;
        this.priceSmall = priceSmall;
        this.priceMedium = priceMedium;
        this.priceLarge = priceLarge;
    }

    // Getters
    public int getImageResource() {
        return imageResource;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPriceSmall() {
        return priceSmall;
    }

    public double getPriceMedium() {
        return priceMedium;
    }

    public double getPriceLarge() {
        return priceLarge;
    }
}
