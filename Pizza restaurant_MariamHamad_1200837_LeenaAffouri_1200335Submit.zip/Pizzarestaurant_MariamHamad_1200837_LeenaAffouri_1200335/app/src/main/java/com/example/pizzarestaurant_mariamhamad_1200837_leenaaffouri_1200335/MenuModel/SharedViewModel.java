package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav.FavoriteModel;

import java.util.ArrayList;
import java.util.List;

public class SharedViewModel extends ViewModel {
    private MutableLiveData<List<CartModel>> cartItems = new MutableLiveData<>();
    private MutableLiveData<List<FavoriteModel>> favoritesList = new MutableLiveData<>();

    // Method to add item to favorites
    public void addToFavorites(FavoriteModel item) {
        List<FavoriteModel> currentFavorites = favoritesList.getValue();
        if (currentFavorites == null) currentFavorites = new ArrayList<>();
        currentFavorites.add(item);
        favoritesList.setValue(currentFavorites);
        // Add any additional logic or database updates here if necessary
    }

    public void updateFavoritesSortOrder(boolean sortAscending) {
        if (favoritesList.getValue() != null) {
            List<FavoriteModel> sortedFavorites = new ArrayList<>(favoritesList.getValue());
            if (sortAscending) {
                sortedFavorites.sort((o1, o2) -> o1.getName().compareTo(o2.getName()));
            } else {
                sortedFavorites.sort((o1, o2) -> o2.getName().compareTo(o1.getName()));
            }
            favoritesList.postValue(sortedFavorites);
        }
    }


    public LiveData<List<CartModel>> getCartItems() {
        return cartItems;
    }
    public LiveData<List<FavoriteModel>> getFavorites() {
        return favoritesList;
    }
    public void addCartItem(CartModel item) {
        List<CartModel> currentItems = cartItems.getValue();
        if (currentItems == null) {
            currentItems = new ArrayList<>();
        }
        currentItems.add(item);
        cartItems.setValue(currentItems);
    }



    public void removeCartItem(int position) {
        List<CartModel> updatedList = cartItems.getValue();
        if (updatedList != null && position >= 0 && position < updatedList.size()) {
            updatedList.remove(position);
            cartItems.setValue(updatedList); // Properly update LiveData
        }
    }

    // Method to remove item from favorites
    public void removeFavoriteItem(int position) {
        List<FavoriteModel> updatedFavorites = favoritesList.getValue();
        if (updatedFavorites != null && position >= 0 && position < updatedFavorites.size()) {
            updatedFavorites.remove(position);
            favoritesList.setValue(updatedFavorites);  // Update the LiveData with the new list
        }
    }
    public List<FavoriteModel> getFilteredFavorites(String query) {
        List<FavoriteModel> filteredList = new ArrayList<>();
        if (query == null || query.isEmpty()) {
            filteredList.addAll(favoritesList.getValue());
        } else {
            for (FavoriteModel item : favoritesList.getValue()) {
                if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(item);
                }
            }
        }
        return filteredList;
    }


}
