package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel;

public class VerticalModel {

    int image;
    String name;
    String timing;
    String rating;
    String price;
     String category;

    public VerticalModel(int image, String name, String timing, String rating, String price, String category) {
        this.image = image;
        this.name = name;
        this.timing = timing;
        this.rating = rating;
        this.price = price;
        this.category = category;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTiming() {
        return timing;
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "VerticalModel{" +
                "image=" + image +
                ", name='" + name + '\'' +
                ", timing='" + timing + '\'' +
                ", rating='" + rating + '\'' +
                ", price='" + price + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}
