package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {
    public interface OnProfileUpdatedListener {
        void onProfileUpdated();
    }

    private EditText firstNameEditText, lastNameEditText, emailEditText, phoneEditText, pass,passconfirm;
    private Button updateButton;
    private Spinner genderSpinner;
    private DataBaseHelper dbHelper;

    
    private String originalEmail; // Class member variable
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        // Initialize DBHelper
        dbHelper = new DataBaseHelper(getActivity(), "customer_Data_base", null, 1);
        // Initialize UI components
        initializeUI(view);

        // Load user data
        loadUserData();

        updateButton.setOnClickListener(v -> updateUserProfile());

        return view;
    }

    private void initializeUI(View view) {
        firstNameEditText = view.findViewById(R.id.FirstNameEditTextF);
        lastNameEditText = view.findViewById(R.id.LastNameEditTextF);
        emailEditText = view.findViewById(R.id.emailEditTextF);
        phoneEditText = view.findViewById(R.id.phoneEditTextF);
        pass = view.findViewById(R.id.passwordEditTextF);
        passconfirm = view.findViewById(R.id.ConfirmpasswordEditTextF);
        genderSpinner = view.findViewById(R.id.genderSpinnerF);
        updateButton = view.findViewById(R.id.buttonUpdateFF);
    }


    private void loadUserData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        originalEmail = sharedPreferences.getString("UserEmail", ""); // Fetch and store the original email
        emailEditText.setText(originalEmail);
        String userEmail = sharedPreferences.getString("UserEmail", "");
        if (!userEmail.isEmpty()) {
            displayUserData(userEmail);
        } else {
            Toast.makeText(getActivity(), "User credentials not available", Toast.LENGTH_LONG).show();
        }
    }



    private void displayUserData(String email) {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getActivity(), "customer_Data_base", null, 1);
        Customer customer = dataBaseHelper.getCustomerByEmail(email); // Ensure this method is safe and efficient
        if (customer != null) {
            firstNameEditText.setText(customer.getFirstName());
            lastNameEditText.setText(customer.getLastName());
            emailEditText.setText(customer.getEmail());
            phoneEditText.setText(customer.getPhone());
            // Set up the spinner for gender selection
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),
                    R.array.gender_array, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            genderSpinner.setAdapter(adapter);

            if (customer.getGender() != null) {
                int spinnerPosition = adapter.getPosition(customer.getGender());
                genderSpinner.setSelection(spinnerPosition, true);
            }
            // Configure spinner for gender
        } else {
            Toast.makeText(getActivity(), "Failed to retrieve user details.", Toast.LENGTH_SHORT).show();
        }
    }





    private void updateUserProfile() {
        String email = emailEditText.getText().toString();

        if (!email.equals(originalEmail)) {
            Toast.makeText(getActivity(), "Email cannot be changed.", Toast.LENGTH_LONG).show();
            emailEditText.setText(originalEmail);
            return;
        }

        String firstName = firstNameEditText.getText().toString();
        String lastName = lastNameEditText.getText().toString();
        String phone = phoneEditText.getText().toString();
        String password = pass.getText().toString();
        String confirmPassword = passconfirm.getText().toString();

        if (!validateInputs(firstName, lastName, email, phone, password, confirmPassword)) {
            Toast.makeText(getActivity(), "Please correct the input data", Toast.LENGTH_LONG).show();
        } else {
            String storedPassword = dbHelper.getStoredPassword(email);
            String hashedInputPassword = dbHelper.hashPassword(password);

            if (storedPassword != null && storedPassword.equals(hashedInputPassword)) {
                dbHelper.updateProfileInDatabase(firstName, lastName, email, phone, password);
                Toast.makeText(getActivity(), "Profile Updated Successfully", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getActivity(), "Incorrect password. Please enter your current password to make changes.", Toast.LENGTH_LONG).show();
            }
        }
    }




    private boolean validateInputs(String firstName, String lastName, String email, String phone, String password, String confirmPassword) {
        if (firstName.length() < 3 || lastName.length() < 3) {
            Toast.makeText(getActivity(), "Name must be at least 3 characters long", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(email) || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(getActivity(), "Invalid email address", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!phone.matches("05[0-9]{8}")) {
            Toast.makeText(getActivity(), "Phone number must be exactly 10 digits and start with '05'", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(password) || password.length() < 8 || confirmPassword.isEmpty()) {
            Toast.makeText(getActivity(), "Password must be at least 8 characters long", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(getActivity(), "Passwords do not match", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

}
