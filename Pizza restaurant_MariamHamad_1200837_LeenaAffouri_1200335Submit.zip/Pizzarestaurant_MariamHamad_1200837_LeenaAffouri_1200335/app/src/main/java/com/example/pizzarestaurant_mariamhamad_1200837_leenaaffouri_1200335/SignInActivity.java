package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignInActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextPassword;
    private CheckBox checkBoxRememberMe;
    private Button buttonSignIn;
    private DataBaseHelper dataBaseHelper;

    private void saveUserEmail(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("UserEmail", email);
        editor.apply();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        // Initialize the views
        editTextEmail = findViewById(R.id.emailEditText);
        editTextPassword = findViewById(R.id.passwordEditText);
        checkBoxRememberMe = findViewById(R.id.checkBoxRememberMe);
        buttonSignIn = findViewById(R.id.buttonSignIn);
        dataBaseHelper = new DataBaseHelper(this, "customer_Data_base", null, 1);

        // Load previously saved preferences
        loadPreferences();

// Set the login button's onClick listener
        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call login method when button is clicked
                login();
                saveUserEmail(editTextEmail.getText().toString());
                // Check if "Remember Me" is checked and save preferences if true
                if (checkBoxRememberMe.isChecked()) {
                    savePreferences(editTextEmail.getText().toString());
                }
            }
        });
    }


    private void login() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        if (!email.isEmpty() && !password.isEmpty()) {
            Customer customer = dataBaseHelper.getUserDetails(email, password);
            if (customer != null) {
                Intent navigationIntent = new Intent(SignInActivity.this, CustomerNavigationActivity.class);
                navigationIntent.putExtra("CustomerEmail", customer.getEmail());
                navigationIntent.putExtra("CustomerName", customer.getFirstName() + " " + customer.getLastName());
                startActivity(navigationIntent);
                Toast.makeText(this, "Sign In Successfully!", Toast.LENGTH_SHORT).show();
                saveUserEmail(email);
                finish();  // End this activity
            } else {
                Toast.makeText(this, "Invalid email or password!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter both email and password!", Toast.LENGTH_SHORT).show();
        }
    }



    private boolean validateLogin(String email, String password) {
        // Dummy validation logic
        return !email.isEmpty() && !password.isEmpty(); // Replace with actual validation logic
    }

    private void savePreferences(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Email", email);
        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String savedEmail = sharedPreferences.getString("Email", "");
        editTextEmail.setText(savedEmail);
    }
    public void goToSignUppage (View view){

        Intent signUpIntent = new Intent(SignInActivity.this, SignUpActivity.class);
        startActivity(signUpIntent);
    }


    public void goTONAVIGATION(View view) {
        Log.d("SignIn", "Button clicked. Navigating to CustomerNavigationActivity.");
        Intent intent = new Intent(SignInActivity.this, CustomerNavigationActivity.class);
        startActivity(intent);
    }


}
