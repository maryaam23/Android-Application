package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin.ConnectionAsyncTask;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin.DataBaseHelperAdmin;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin.AdminInfo;

import org.json.JSONObject;

public class SignInAdminActivity extends AppCompatActivity {
    private EditText editTextEmail, editTextPassword;
    private CheckBox checkBoxRememberMe;
    private Button buttonSignIn;
    private DataBaseHelperAdmin dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_admin2);

        // Initialize the views
        editTextEmail = findViewById(R.id.emailEditText);
        editTextPassword = findViewById(R.id.passwordEditText);
        checkBoxRememberMe = findViewById(R.id.checkBoxRememberMe);
        buttonSignIn = findViewById(R.id.buttonSignIn);

        // Initialize the database helper
        dbHelper = new DataBaseHelperAdmin(this);

        // Load saved email if "Remember Me" was previously checked
        loadPreferences();

        // Set the login button's onClick listener
        buttonSignIn.setOnClickListener(v -> {
            if (checkBoxRememberMe.isChecked()) {
                savePreferences(editTextEmail.getText().toString());
            }
            login();
        });
    }

    private void login() {
        String enteredEmail = editTextEmail.getText().toString();
        String enteredPassword = editTextPassword.getText().toString();

        // Check if the email exists in the local database
        if (dbHelper.isAdminExists(enteredEmail)) {
            // Validate the password from the database
            String storedPassword = dbHelper.getAdminPassword(enteredEmail);
            if (storedPassword != null && storedPassword.equals(enteredPassword)) {
                goToAdminNavigation(enteredEmail);
            } else {
                Toast.makeText(this, "Invalid password in the data base", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If not in the database, check the JSON URL
            checkEmailInJson(enteredEmail, enteredPassword);
        }
    }

    private void checkEmailInJson(String enteredEmail, String enteredPassword) {
        ConnectionAsyncTask task = new ConnectionAsyncTask(data -> {
            try {
                JSONObject jsonObject = new JSONObject(data);
                String correctEmail = jsonObject.optString("email");
                String correctPassword = jsonObject.optString("password");
                if (enteredEmail.equals(correctEmail)) {
                    if (enteredPassword.equals(correctPassword)) {
                        // Save the information to the database
                        saveAdminToDatabase(jsonObject);
                        goToAdminNavigation(enteredEmail);
                    } else {
                        Toast.makeText(this, "Invalid password in json", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Invalid email", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        task.execute("https://mocki.io/v1/b38f4b42-76a3-49e6-bfc4-aaad53fdf4a4");
    }

    private void saveAdminToDatabase(JSONObject jsonObject) {
        String email = jsonObject.optString("email");
        String phone = jsonObject.optString("phone_number");
        String firstName = jsonObject.optString("first_name");
        String lastName = jsonObject.optString("last_name");
        String gender = jsonObject.optString("gender");
        String password = jsonObject.optString("password");

        AdminInfo adminInfo = new AdminInfo(email, phone, firstName, lastName, gender, password);
        dbHelper.insertAdmin(adminInfo);
    }

    private void savePreferences(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Email", email);
        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String savedEmail = sharedPreferences.getString("Email", "");
        editTextEmail.setText(savedEmail);
    }



    private void goToAdminNavigation(String email) {
        Log.d("SignIn", "Navigating to AdminNavigationActivity.");
        Intent intent = new Intent(SignInAdminActivity.this, AdminNavigationActivity.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }
}
