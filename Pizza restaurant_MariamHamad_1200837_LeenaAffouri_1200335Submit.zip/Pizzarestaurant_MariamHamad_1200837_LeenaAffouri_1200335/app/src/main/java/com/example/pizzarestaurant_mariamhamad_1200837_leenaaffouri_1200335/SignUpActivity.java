package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import android.util.Base64;
import android.view.View;


public class SignUpActivity extends AppCompatActivity {
    private EditText firstName, lastName, phoneNumber, email, password, confirmPassword;
    private Spinner genderSpinner;
    private Button signUpButton;

    private TextView genderError;

    DataBaseHelper dataBaseHelper = new DataBaseHelper(SignUpActivity.this, "customer_Data_base", null, 1);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Initialize UI Components
        firstName = findViewById(R.id.FirstNameEditText);
        lastName = findViewById(R.id.LastNameEditText);
        phoneNumber = findViewById(R.id.phoneEditText);
        email = findViewById(R.id.emailEditText);
        password = findViewById(R.id.passwordEditText);
        confirmPassword = findViewById(R.id.ConfirmpasswordEditText);
        genderSpinner = findViewById(R.id.genderSpinner);
        signUpButton = findViewById(R.id.signUpButton);
        genderError = findViewById(R.id.genderError);
        // Set up the spinner for gender selection
        ArrayAdapter<CharSequence> genderAdapter = ArrayAdapter.createFromResource(this,R.array.gender_array, android.R.layout.simple_spinner_item);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(genderAdapter);



        // Set up the sign-up button click listener
        signUpButton.setOnClickListener(v -> {
            if (validateInputs()) {
                // Proceed to register the user

                logAllCustomers();
                registerUser();
            }
        });


    }
    private void logAllCustomers() {
        DataBaseHelper dbHelper = new DataBaseHelper(this, "customer_Data_base", null, 1);
        List<Customer> customers = dbHelper.getAllCustomers();

        for (Customer customer : customers) {
            Log.d("CustomerData", "Email: " + customer.getEmail() +
                    ", First Name: " + customer.getFirstName() +
                    ", Last Name: " + customer.getLastName() +
                    ", Phone: " + customer.getPhone() +
                    ", Gender: " + customer.getGender() +
                    ", Password: " + customer.getPassword()); // Be cautious with logging sensitive data like passwords
        }
    }

    private boolean validateInputs() {
        // Validate all inputs here
        if (firstName.getText().toString().trim().length() < 3) {
            firstName.setError("First name must be at least 3 characters long");
            return false;
        }
        if (lastName.getText().toString().trim().length() < 3) {
            lastName.setError("Last name must be at least 3 characters long");
            return false;
        }
        if (dataBaseHelper.emailExists(email.getText().toString())) {
            email.setError("Email already in use, go to log in");
            Toast.makeText(this, "The email is already exist!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
            startActivity(intent);
            return false;  // Make sure to stop the registration process here



    }else  if (!email.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")) {
                email.setError("Enter a valid email");
                return false;
        }
        if (!phoneNumber.getText().toString().matches("05[0-9]{8}")) {
            phoneNumber.setError("Phone number must be exactly 10 digits and start with '05'");
            return false;
        }
        if (password.getText().toString().length() < 8 || !password.getText().toString().matches(".*[a-zA-Z]+.*") || !password.getText().toString().matches(".*[0-9]+.*")) {
            password.setError("Password must be at least 8 characters long and include at least one letter and one number");
            return false;
        }
        if (!confirmPassword.getText().toString().equals(password.getText().toString())) {
            confirmPassword.setError("Passwords do not match");
            return false;
        }
        String gender = genderSpinner.getSelectedItem().toString();
        if (gender.equals("Gender")) {
            genderError.setText("You must choose a gender"); // Set error message below the spinner
            genderError.setVisibility(View.VISIBLE); // Make sure the error is visible
            return false;
        } else {
            genderError.setVisibility(View.GONE); // Hide the error message if the selection is valid
        }



        return true;

    }
    private void registerUser() {
        // Notify user of successful registration
        Toast.makeText(this, "User Registered Successfully!", Toast.LENGTH_SHORT).show();


        // Hash the password before storing it
        String hashedPassword = hashPassword(password.getText().toString());

        // Create and insert the customer into the database
        createCustomerAndInsertToDb(email.getText().toString(),
                firstName.getText().toString(),
                lastName.getText().toString(),
                phoneNumber.getText().toString(),
                hashedPassword,
                genderSpinner.getSelectedItem().toString());



        // Delay redirection to the sign-in page after showing the toast
        new android.os.Handler().postDelayed(() -> {
            Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
            startActivity(intent);
            finish();  // Finish the current activity
        }, Toast.LENGTH_SHORT);
    }


    private void createCustomerAndInsertToDb(String email, String firstName, String lastName, String phoneNumber, String password, String gender) {
        Customer newCustomer = new Customer();
        newCustomer.setEmail(email);
        newCustomer.setFirstName(firstName);
        newCustomer.setLastName(lastName);
        newCustomer.setPhone(phoneNumber);
        newCustomer.setPassword(password);
        newCustomer.setGender(gender);

        //DataBaseHelper dataBaseHelper = new DataBaseHelper(SignUpActivity.this, "customer_Data_base", null, 1);
        dataBaseHelper.insertCustomer(newCustomer);
    }



    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(encodedhash, Base64.DEFAULT);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void goToSignINpage (View view){
        Intent signInIntent = new Intent(SignUpActivity.this, SignInActivity.class);
        startActivity(signInIntent);

    }

    private void saveUserEmail(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("UserEmail", email);
        editor.apply();
    }

}