package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.AddAdmin;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin.DataBaseHelperAdmin;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin.AdminInfo;

public class AddAdmin extends Fragment {
    private EditText firstName, lastName, phoneNumber, email, password, confirmPassword;
    private Spinner genderSpinner;
    private Button addButton;
    private TextView genderError;
    private DataBaseHelperAdmin dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_admin, container, false);

        // Initialize UI Components
        firstName = view.findViewById(R.id.firstNameEditText);
        lastName = view.findViewById(R.id.LastNameEditText);
        phoneNumber = view.findViewById(R.id.phoneEditText);
        email = view.findViewById(R.id.emailEditText);
        password = view.findViewById(R.id.passwordEditText);
        confirmPassword = view.findViewById(R.id.ConfirmpasswordEditText);
        genderSpinner = view.findViewById(R.id.genderSpinner);
        addButton = view.findViewById(R.id.addButton);
        genderError = view.findViewById(R.id.genderError);

        // Initialize the database helper
        dbHelper = new DataBaseHelperAdmin(getContext());

        // Set up the spinner for gender selection
        ArrayAdapter<CharSequence> genderAdapter = ArrayAdapter.createFromResource(getContext(), R.array.gender_array, android.R.layout.simple_spinner_item);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(genderAdapter);

        addButton.setOnClickListener(v -> {
            if (validateInputs()) {
                addAdmin();
            }
        });

        return view;
    }

    private boolean validateInputs() {
        boolean isValid = true;

        if (firstName.getText().toString().trim().length() < 3) {
            firstName.setError("First name must be at least 3 characters long");
            isValid = false;
        }
        if (lastName.getText().toString().trim().length() < 3) {
            lastName.setError("Last name must be at least 3 characters long");
            isValid = false;
        }
        if (!phoneNumber.getText().toString().matches("05[0-9]{8}")) {
            phoneNumber.setError("Phone number must be exactly 10 digits and start with '05'");
            isValid = false;
        }
        if (password.getText().toString().length() < 8 || !password.getText().toString().matches(".*[a-zA-Z]+.*") || !password.getText().toString().matches(".*[0-9]+.*")) {
            password.setError("Password must be at least 8 characters long and include at least one letter and one number");
            isValid = false;
        }
        if (!confirmPassword.getText().toString().equals(password.getText().toString())) {
            confirmPassword.setError("Passwords do not match");
            isValid = false;
        }
        if (genderSpinner.getSelectedItemPosition() == 0) {
            genderError.setText("Please select a gender");
            isValid = false;
        } else {
            genderError.setText(null);
        }

        return isValid;
    }

    private void addAdmin() {
        String adminFirstName = firstName.getText().toString().trim();
        String adminLastName = lastName.getText().toString().trim();
        String adminPhone = phoneNumber.getText().toString().trim();
        String adminEmail = email.getText().toString().trim();
        String adminPassword = password.getText().toString().trim();
        String adminGender = genderSpinner.getSelectedItem().toString();

        AdminInfo adminInfo = new AdminInfo(adminEmail, adminPhone, adminFirstName, adminLastName, adminGender, adminPassword);

        if (dbHelper.isAdminExists(adminEmail)) {
            Toast.makeText(getContext(), "Admin with this email already exists", Toast.LENGTH_SHORT).show();
        } else {
            boolean isInserted = dbHelper.insertAdmin(adminInfo);
            if (isInserted) {
                Toast.makeText(getContext(), "Admin added successfully", Toast.LENGTH_SHORT).show();
                clearFields();
            } else {
                Toast.makeText(getContext(), "Failed to add admin", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void clearFields() {
        firstName.setText("");
        lastName.setText("");
        phoneNumber.setText("");
        email.setText("");
        password.setText("");
        confirmPassword.setText("");
        genderSpinner.setSelection(0);
    }
}
