package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.Offer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;

import java.util.List;

public class SpecialOffersAdapter extends RecyclerView.Adapter<SpecialOffersAdapter.SpecialOfferViewHolder> {
    private List<SpecialOffersFragment> offers; // Your data model

    @NonNull
    @Override
    public SpecialOfferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_special_offer, parent, false);
        return new SpecialOfferViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SpecialOfferViewHolder holder, int position) {
        SpecialOffersFragment offer = offers.get(position);
        // Set data in holder
    }

    @Override
    public int getItemCount() {
        return (offers != null) ? offers.size() : 0;
    }


    class SpecialOfferViewHolder extends RecyclerView.ViewHolder {
        // View holder setup
        public SpecialOfferViewHolder(View itemView) {
            super(itemView);
            // initialize views
        }
    }
}
