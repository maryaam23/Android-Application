package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.Offer;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;


public class SpecialOffersFragment extends Fragment {

    private RecyclerView recyclerView;
    private SpecialOffersAdapter adapter;

    public SpecialOffersFragment() {
        // Required empty public constructor
    }

    public static SpecialOffersFragment newInstance() {
        return new SpecialOffersFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_special_offers, container, false);
        recyclerView = view.findViewById(R.id.rvSpecialOffers);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new SpecialOffersAdapter(); // Assuming you have an adapter for the special offers
        recyclerView.setAdapter(adapter);
        return view;
    }
}