package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.ViewOrders;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;


public class ViewAllOrders extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_all_orders, container, false);
    }
}