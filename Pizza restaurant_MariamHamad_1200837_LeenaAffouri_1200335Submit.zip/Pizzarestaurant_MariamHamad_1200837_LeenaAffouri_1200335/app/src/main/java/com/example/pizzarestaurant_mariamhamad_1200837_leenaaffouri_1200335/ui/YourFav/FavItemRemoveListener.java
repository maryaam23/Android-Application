package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav;


public interface FavItemRemoveListener {
    void onremoveFavoriteItem(int position);
}

