package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav.FavItemRemoveListener;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.CartAdapter;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;


import java.util.List;


public class FavoriteAdapter  extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder>{

    private FavItemRemoveListener listener;
    private Context context;
    private List<FavoriteModel> list;

    public FavoriteAdapter(Context context, List<FavoriteModel> list) {
        this.context = context;
        this.list = list;
    }

    public FavoriteAdapter(List<FavoriteModel> list) {

        this.list=list;
    }
    public FavoriteAdapter(Context context, List<FavoriteModel> list, FavItemRemoveListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    public void updateData(List<FavoriteModel> newFavorites) {
        this.list = newFavorites;
        notifyDataSetChanged(); // Notify the adapter to refresh the list
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.myfav_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FavoriteModel item = list.get(position);
        holder.FimageView.setImageResource(item.getImage());
        holder.Fname.setText(item.getName());
        holder.Frating.setText(item.getRating()); // Make sure 'getRating()' returns a String
        holder.Fprice.setText(item.getPrice());

        holder.FdeleteButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onremoveFavoriteItem(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView FimageView;
        TextView Fname, Frating, Fprice;
        ImageButton FdeleteButton;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            FimageView = itemView.findViewById(R.id.Favimg);
            Fname = itemView.findViewById(R.id.Favname);
            Frating = itemView.findViewById(R.id.Favdetailed_rating);
            Fprice = itemView.findViewById(R.id.Favprice_amount); // Updated the ID based on your image
            FdeleteButton = itemView.findViewById(R.id.Favdelete_button);
        }
    }
}
