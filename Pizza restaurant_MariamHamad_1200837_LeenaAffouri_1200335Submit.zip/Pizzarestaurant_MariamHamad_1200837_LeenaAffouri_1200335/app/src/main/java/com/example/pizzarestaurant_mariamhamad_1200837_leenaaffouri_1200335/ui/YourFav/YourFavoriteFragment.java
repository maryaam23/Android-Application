package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.CartAdapter;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.SharedViewModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;

import java.util.List;

public class YourFavoriteFragment extends Fragment implements FavItemRemoveListener{

    private RecyclerView recyclerView;
    private FavoriteAdapter favoriteAdapter;
    private SharedViewModel viewModel;

    private ImageButton sortButton;
    private boolean sortAscending = true;

    private EditText searchBar;


    public YourFavoriteFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_your_favorite, container, false);
        recyclerView = view.findViewById(R.id.Fav_rec);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        viewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        // Assuming getFavorites() is a method you need to implement that returns LiveData<List<FavoriteModel>>
        viewModel.getFavorites().observe(getViewLifecycleOwner(), favorites -> {
            favoriteAdapter = new FavoriteAdapter(getContext(), favorites,this);
            recyclerView.setAdapter(favoriteAdapter);
        });


        sortButton = view.findViewById(R.id.sortButton);
        sortButton.setOnClickListener(v -> toggleSortOrder());

        viewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        viewModel.getFavorites().observe(getViewLifecycleOwner(), favorites -> {
            if (sortAscending) {
                favorites.sort((o1, o2) -> o1.getName().compareTo(o2.getName()));
            }
            favoriteAdapter = new FavoriteAdapter(getContext(), favorites, this);
            recyclerView.setAdapter(favoriteAdapter);
        });


        searchBar = view.findViewById(R.id.searchBar);
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterFavorites(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


        return view;
    }

    private void filterFavorites(String text) {
        List<FavoriteModel> filteredList = viewModel.getFilteredFavorites(text);
        favoriteAdapter.updateData(filteredList);
    }


    private void toggleSortOrder() {
        sortAscending = !sortAscending; // Toggle the sort order
        viewModel.updateFavoritesSortOrder(sortAscending); // Method to sort data in ViewModel
    }


    @Override
    public void onremoveFavoriteItem(int position) {
        if (viewModel != null) {
            viewModel.removeFavoriteItem(position);

        }
    }


}