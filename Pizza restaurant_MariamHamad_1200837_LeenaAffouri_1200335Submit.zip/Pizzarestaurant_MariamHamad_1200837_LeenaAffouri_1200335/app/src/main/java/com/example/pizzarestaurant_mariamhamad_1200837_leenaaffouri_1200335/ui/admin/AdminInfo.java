package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin;

public class AdminInfo {
    private String email ;
    private String phone_number ;
    private String first_name ;
    private String last_name ;

    private String gender;
    private String admin_password;


    public AdminInfo() {
    }

    public AdminInfo(String email, String phone_number, String first_name, String last_name, String gender, String admin_password) {
        this.email = email;
        this.phone_number = phone_number;
        this.first_name = first_name;
        this.last_name = last_name;
        this.gender = gender;
        this.admin_password = admin_password;
    }

    public String getAdminEmail() {
        return email;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public String getFirst_name() {
        return first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public String getGender() {
        return gender;
    }

    public String getAdminPassword() {
        return admin_password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAdmin_password(String admin_password) {
        this.admin_password = admin_password;
    }

    @Override
    public String toString() {
        return "AdminInfo{" +
                "email='" + email + '\'' +
                ", phone_number='" + phone_number + '\'' +
                ", first_name='" + first_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", gender='" + gender + '\'' +
                ", admin_password='" + admin_password + '\'' +
                '}';
    }
}
