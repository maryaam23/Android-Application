package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AdminJsonParser {
    public static List<AdminInfo> getObjectFromJson(String json) {
        List<AdminInfo> admins;
        try {
            JSONArray jsonArray = new JSONArray(json);
            admins = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = new JSONObject();
                jsonObject = (JSONObject) jsonArray.get(i);
                AdminInfo admin = new AdminInfo();
                admin.setEmail(jsonObject.getString("email"));
                admin.setPhone_number(jsonObject.getString("phone_number"));
                admin.setFirst_name(jsonObject.getString("first_name"));
                admin.setLast_name(jsonObject.getString("last_name"));
                admin.setGender(jsonObject.getString("gender"));
                admin.setAdmin_password(jsonObject.getString("admin_password"));
                admins.add(admin);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return admins;
    }

}
