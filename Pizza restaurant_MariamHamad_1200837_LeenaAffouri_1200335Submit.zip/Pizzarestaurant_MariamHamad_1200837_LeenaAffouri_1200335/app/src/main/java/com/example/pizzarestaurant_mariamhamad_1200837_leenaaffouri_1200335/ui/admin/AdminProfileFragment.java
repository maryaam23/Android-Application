package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class AdminProfileFragment extends Fragment {

    private TextView emailTextView;
    private EditText phoneEditText;
    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private TextView genderTextView;
    private EditText passwordEditText;
    private EditText confirmPasswordEditText;
    private ProgressBar progressBar;
    private Button updateButton;
    private Button dpButton;

    private DataBaseHelperAdmin dbHelper;
    private String email;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_profile, container, false);

        emailTextView = view.findViewById(R.id.emailTextView);
        phoneEditText = view.findViewById(R.id.phoneEditText);
        firstNameEditText = view.findViewById(R.id.FirstNameEditText);
        lastNameEditText = view.findViewById(R.id.LastNameEditText);
        genderTextView = view.findViewById(R.id.gender);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        confirmPasswordEditText = view.findViewById(R.id.ConfirmpasswordEditText);
        progressBar = view.findViewById(R.id.progressBar);
        updateButton = view.findViewById(R.id.updateButton);
        dpButton = view.findViewById(R.id.dpButton);

        dbHelper = new DataBaseHelperAdmin(getContext());

        // Get the email from the activity intent
        if (getActivity() != null) {
            email = getActivity().getIntent().getStringExtra("email");
        }

        loadData();

        dpButton.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), ViewDatabaseActivity.class);
            startActivity(intent);
        });

        updateButton.setOnClickListener(v -> {
            if (validateInputs()) {
                updateAdminInfo();
            }
        });

        return view;
    }

    private void loadData() {
        // Show progress bar while loading
        progressBar.setVisibility(View.VISIBLE);

        if (email != null && !email.isEmpty()) {
            if (dbHelper.isAdminExists(email)) {
                // Load data from the database
                updateProfileFromDatabase(email);
            } else {
                // Load data from the JSON
                ConnectionAsyncTask task = new ConnectionAsyncTask(data -> {
                    try {
                        JSONArray jsonArray = new JSONArray(data);
                        boolean emailFound = false;

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String jsonEmail = jsonObject.optString("email");

                            if (email.equals(jsonEmail)) {
                                emailFound = true;
                                updateProfileFromJson(jsonObject);
                                break;
                            }
                        }

                        if (!emailFound) {
                            Toast.makeText(getContext(), "Email not found in JSON", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    progressBar.setVisibility(View.GONE);
                });
                task.execute("https://mocki.io/v1/b38f4b42-76a3-49e6-bfc4-aaad53fdf4a4");
            }
        } else {
            Toast.makeText(getContext(), "No email provided", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
        }
    }

    private void updateProfileFromDatabase(String email) {
        AdminInfo adminInfo = dbHelper.getAdminInfo(email);
        if (adminInfo != null) {
            emailTextView.setText(adminInfo.getAdminEmail());
            phoneEditText.setText(adminInfo.getPhone_number());
            firstNameEditText.setText(adminInfo.getFirst_name());
            lastNameEditText.setText(adminInfo.getLast_name());
            genderTextView.setText(adminInfo.getGender());
            passwordEditText.setText(adminInfo.getAdminPassword());
            Toast.makeText(getContext(), "Admin info loaded from database", Toast.LENGTH_SHORT).show();
        }
        progressBar.setVisibility(View.GONE);
    }

    private void updateProfileFromJson(JSONObject jsonObject) {
        try {
            String email = jsonObject.optString("email");
            String phone = jsonObject.optString("phone_number");
            String firstName = jsonObject.optString("first_name");
            String lastName = jsonObject.optString("last_name");
            String gender = jsonObject.optString("gender");
            String password = jsonObject.optString("password");

            emailTextView.setText(email);
            phoneEditText.setText(phone);
            firstNameEditText.setText(firstName);
            lastNameEditText.setText(lastName);
            genderTextView.setText(gender);
            passwordEditText.setText(password);

            // Save admin info to the database
            AdminInfo adminInfo = new AdminInfo(email, phone, firstName, lastName, gender, password);
            boolean isInserted = dbHelper.insertAdmin(adminInfo);
            if (isInserted) {
                Toast.makeText(getContext(), "Admin info loaded from JSON and saved to database", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Failed to save admin info to database", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateAdminInfo() {
        String email = emailTextView.getText().toString();
        String phone = phoneEditText.getText().toString();
        String firstName = firstNameEditText.getText().toString();
        String lastName = lastNameEditText.getText().toString();
        String gender = genderTextView.getText().toString();
        String password = passwordEditText.getText().toString();

        AdminInfo adminInfo = new AdminInfo(email, phone, firstName, lastName, gender, password);
        boolean isUpdated = dbHelper.updateAdmin(adminInfo);
        if (isUpdated) {
            Toast.makeText(getContext(), "Admin info updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "Failed to update admin info", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateInputs() {
        // Validate all inputs here
        if (firstNameEditText.getText().toString().trim().length() < 3) {
            firstNameEditText.setError("First name must be at least 3 characters long");
            return false;
        }
        if (lastNameEditText.getText().toString().trim().length() < 3) {
            lastNameEditText.setError("Last name must be at least 3 characters long");
            return false;
        }
        if (!phoneEditText.getText().toString().matches("05[0-9]{8}")) {
            phoneEditText.setError("Phone number must be exactly 10 digits and start with '05'");
            return false;
        }
        if (passwordEditText.getText().toString().length() < 8 || !passwordEditText.getText().toString().matches(".*[a-zA-Z]+.*") || !passwordEditText.getText().toString().matches(".*[0-9]+.*")) {
            passwordEditText.setError("Password must be at least 8 characters long and include at least one letter and one number");
            return false;
        }
        if (!confirmPasswordEditText.getText().toString().equals(passwordEditText.getText().toString())) {
            confirmPasswordEditText.setError("Passwords do not match");
            return false;
        }
        return true;
    }
}
