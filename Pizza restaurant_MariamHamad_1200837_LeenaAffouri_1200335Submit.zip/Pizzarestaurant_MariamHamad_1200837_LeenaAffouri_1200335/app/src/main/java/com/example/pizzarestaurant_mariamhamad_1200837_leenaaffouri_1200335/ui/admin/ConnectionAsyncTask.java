package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin;

import android.os.AsyncTask;
import java.util.List;

public class ConnectionAsyncTask extends AsyncTask<String, Void, String> {
    private final OnProfileDataReceivedListener listener;

    public ConnectionAsyncTask(OnProfileDataReceivedListener listener) {
        this.listener = listener;
    }

    @Override
    protected String doInBackground(String... params) {
        return HttpManager.getData(params[0]);
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        if (listener != null) {
            listener.onDataReceived(result);
        }
    }

    public interface OnProfileDataReceivedListener {
        void onDataReceived(String data);
    }
}


