package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelperAdmin extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "admin.db";
    private static final int DATABASE_VERSION = 1;

    public DataBaseHelperAdmin(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE ADMIN(EMAIL TEXT PRIMARY KEY, PHONE TEXT, FIRSTNAME TEXT, LASTNAME TEXT, GENDER TEXT, PASSWORD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS ADMIN");
        onCreate(sqLiteDatabase);
    }

    public boolean insertAdmin(AdminInfo adminInfo) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("EMAIL", adminInfo.getAdminEmail());
        contentValues.put("PHONE", adminInfo.getPhone_number());
        contentValues.put("FIRSTNAME", adminInfo.getFirst_name());
        contentValues.put("LASTNAME", adminInfo.getLast_name());
        contentValues.put("GENDER", adminInfo.getGender());
        contentValues.put("PASSWORD", adminInfo.getAdminPassword());
        long result = sqLiteDatabase.insert("ADMIN", null, contentValues);
        sqLiteDatabase.close();
        return result != -1;
    }

    public boolean updateAdmin(AdminInfo adminInfo) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("PHONE", adminInfo.getPhone_number());
        contentValues.put("FIRSTNAME", adminInfo.getFirst_name());
        contentValues.put("LASTNAME", adminInfo.getLast_name());
        contentValues.put("GENDER", adminInfo.getGender());
        contentValues.put("PASSWORD", adminInfo.getAdminPassword());
        int result = sqLiteDatabase.update("ADMIN", contentValues, "EMAIL = ?", new String[]{adminInfo.getAdminEmail()});
        sqLiteDatabase.close();
        return result > 0;
    }

    public boolean isAdminExists(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM ADMIN WHERE EMAIL = ?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public String getAdminPassword(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT PASSWORD FROM ADMIN WHERE EMAIL = ?", new String[]{email});
        String password = null;
        if (cursor.moveToFirst()) {
            password = cursor.getString(cursor.getColumnIndex("PASSWORD"));
        }
        cursor.close();
        return password;
    }

    public AdminInfo getAdminInfo(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM ADMIN WHERE EMAIL = ?", new String[]{email});
        AdminInfo adminInfo = null;
        if (cursor.moveToFirst()) {
            String phone = cursor.getString(cursor.getColumnIndex("PHONE"));
            String firstName = cursor.getString(cursor.getColumnIndex("FIRSTNAME"));
            String lastName = cursor.getString(cursor.getColumnIndex("LASTNAME"));
            String gender = cursor.getString(cursor.getColumnIndex("GENDER"));
            String password = cursor.getString(cursor.getColumnIndex("PASSWORD"));
            adminInfo = new AdminInfo(email, phone, firstName, lastName, gender, password);
        }
        cursor.close();
        return adminInfo;
    }

    public List<AdminInfo> getAllAdmins() {
        List<AdminInfo> adminList = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM ADMIN", null);
        if (cursor.moveToFirst()) {
            do {
                String email = cursor.getString(cursor.getColumnIndex("EMAIL"));
                String phone = cursor.getString(cursor.getColumnIndex("PHONE"));
                String firstName = cursor.getString(cursor.getColumnIndex("FIRSTNAME"));
                String lastName = cursor.getString(cursor.getColumnIndex("LASTNAME"));
                String gender = cursor.getString(cursor.getColumnIndex("GENDER"));
                String password = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                AdminInfo admin = new AdminInfo(email, phone, firstName, lastName, gender, password);
                adminList.add(admin);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return adminList;
    }
}
