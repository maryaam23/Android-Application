package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.admin;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;
import java.util.List;

public class ViewDatabaseActivity extends AppCompatActivity {

    private TextView databaseContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_database);

        databaseContent = findViewById(R.id.databaseContent);
        displayDatabaseContent();
    }

    private void displayDatabaseContent() {
        DataBaseHelperAdmin dbHelper = new DataBaseHelperAdmin(this);
        List<AdminInfo> adminList = dbHelper.getAllAdmins();
        StringBuilder content = new StringBuilder();
        for (AdminInfo admin : adminList) {
            content.append("Email: ").append(admin.getAdminEmail()).append("\n")
                    .append("Phone: ").append(admin.getPhone_number()).append("\n")
                    .append("First Name: ").append(admin.getFirst_name()).append("\n")
                    .append("Last Name: ").append(admin.getLast_name()).append("\n")
                    .append("Gender: ").append(admin.getGender()).append("\n")
                    .append("Password: ").append(admin.getAdminPassword()).append("\n\n");
        }
        databaseContent.setText(content.toString());
    }
}
