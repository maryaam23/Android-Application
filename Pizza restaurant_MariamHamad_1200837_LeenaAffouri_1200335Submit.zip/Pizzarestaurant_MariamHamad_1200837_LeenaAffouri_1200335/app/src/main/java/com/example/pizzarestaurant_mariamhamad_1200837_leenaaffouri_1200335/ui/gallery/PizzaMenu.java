package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.gallery;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.Adapter;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.UpdateVerticalRec;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.VerticalAdapter;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.Model;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.VerticalModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class PizzaMenu extends Fragment implements UpdateVerticalRec {

    RecyclerView HorizontalRec , VerticalRec;
    ArrayList<Model> ModelList;
    Adapter AdapterList;
    private SearchView searchView;
    String se;
    private RecyclerView verticalRecyclerView;
    private PizzaMenu binding;
    //for vertical
    ArrayList<VerticalModel> VerModelList;
    VerticalAdapter VerAdapterList;

    @SuppressLint("WrongViewCast")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.pizza_menu_fragment, container, false);
        VerticalRec = root.findViewById(R.id.home_Ver_rec);
        HorizontalRec = root.findViewById(R.id.home_hor_rec);
        ModelList = new ArrayList<>();
        ModelList.add(new Model(R.drawable.pizzapeace, "Pizza"));
        ModelList.add(new Model(R.drawable.appetizers, "Appetizers"));
        ModelList.add(new Model(R.drawable.salad, "Salads"));
        ModelList.add(new Model(R.drawable.dessert, "Desserts"));
        ModelList.add(new Model(R.drawable.drinks, "Drinks"));


        AdapterList= new Adapter(this,getActivity(),ModelList);
        HorizontalRec.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.HORIZONTAL, false));
        HorizontalRec.setAdapter(AdapterList);
        //HorizontalRec.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.HORIZONTAL, false));
        HorizontalRec.setHasFixedSize(true);
        HorizontalRec.setNestedScrollingEnabled(false);

// vertical view
        VerModelList = new ArrayList<>();

        VerAdapterList = new VerticalAdapter(getActivity(),VerModelList);
        VerticalRec.setAdapter(VerAdapterList);
        VerticalRec.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));


        se = String.valueOf(root.findViewById(R.id.editText3));


        return root;
    }




    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void callBack(int position, ArrayList<VerticalModel> list) {


        VerAdapterList = new VerticalAdapter(getContext(), list);
        VerAdapterList.notifyDataSetChanged();
        VerticalRec.setAdapter(VerAdapterList);

    }
}