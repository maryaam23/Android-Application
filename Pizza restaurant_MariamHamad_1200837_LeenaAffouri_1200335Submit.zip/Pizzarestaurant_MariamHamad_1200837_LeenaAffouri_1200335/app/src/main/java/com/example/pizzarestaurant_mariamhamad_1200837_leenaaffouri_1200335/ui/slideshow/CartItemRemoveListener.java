package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.slideshow;

public interface CartItemRemoveListener {
    void onItemRemoved(int position);
}