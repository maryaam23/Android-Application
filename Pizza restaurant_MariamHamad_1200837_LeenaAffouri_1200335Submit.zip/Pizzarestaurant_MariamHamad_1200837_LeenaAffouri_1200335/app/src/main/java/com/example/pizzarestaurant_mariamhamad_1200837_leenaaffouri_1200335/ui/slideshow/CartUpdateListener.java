package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.slideshow;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;

public interface CartUpdateListener {
    void onAddToCart(CartModel cartItem);

}
