package com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.slideshow;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuAdapter.CartAdapter;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.CartModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.MenuModel.SharedViewModel;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.R;
import com.example.pizzarestaurant_mariamhamad_1200837_leenaaffouri_1200335.ui.YourFav.FavoriteAdapter;

import java.util.ArrayList;
import java.util.List;

public class Yourorders extends Fragment implements CartItemRemoveListener  {


    List<CartModel> list;
    CartAdapter cartAdapter;
    RecyclerView recyclerView;
    private SharedViewModel viewModel;

    private TextView totalValueTextView;


    public Yourorders(){

    }
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.your_orders_fragment,container,false);
        recyclerView = view.findViewById(R.id.cart_rec);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        viewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        // Inside onCreateView of Yourorders
        viewModel.getCartItems().observe(getViewLifecycleOwner(), items -> {
            cartAdapter = new CartAdapter(getContext(), items, this); // Now 'this' is clearly a CartItemRemoveListener
            recyclerView.setAdapter(cartAdapter);
        });

        totalValueTextView = view.findViewById(R.id.total_value);  // Make sure this ID matches your layout

        viewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        viewModel.getCartItems().observe(getViewLifecycleOwner(), items -> {
            cartAdapter = new CartAdapter(getContext(), items, this);
            recyclerView.setAdapter(cartAdapter);
            updateTotalPrice(items);  // Call this to update the total when items change
        });

        // Return the inflated view
        return view;
    }


    @Override
    public void onItemRemoved(int position) {
        if (viewModel != null) {
            viewModel.removeCartItem(position);
           
        }
    }

    private void updateTotalPrice(List<CartModel> items) {
        double total = 0;
        for (CartModel item : items) {
            try {
                String cleanPrice = item.getPrice().replaceAll("[^\\d.]", ""); // Remove everything but numbers and dot
                double price = Double.parseDouble(cleanPrice);
                int quantity = item.getQuantity();
                total += price;
            } catch (NumberFormatException e) {
                Log.e("Yourorders", "Error parsing price: " + item.getPrice(), e);
            }
        }
        totalValueTextView.setText("$" + String.format("%.2f", total));
    }



}